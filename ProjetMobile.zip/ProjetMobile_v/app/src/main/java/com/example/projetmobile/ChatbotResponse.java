package com.example.projetmobile;

public class ChatbotResponse {
    private String answerText;

    public String getAnswerText() {
        return answerText;
    }
}
