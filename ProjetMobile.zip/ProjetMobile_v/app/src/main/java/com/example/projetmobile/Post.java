package com.example.projetmobile;

public class Post {

        private int userId;
        private int id;
        private String title;
        private String body;

        // Getters for each field
        public int getUserId() { return userId; }
        public int getId() { return id; }
        public String getTitle() { return title; }
        public String getBody() { return body; }


}
