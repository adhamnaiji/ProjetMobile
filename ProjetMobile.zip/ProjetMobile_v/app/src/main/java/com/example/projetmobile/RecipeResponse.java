package com.example.projetmobile;

import java.util.List;

public class RecipeResponse {
    private List<Recipe> results;

    // Getter and Setter for results
    public List<Recipe> getResults() {
        return results;
    }

    public void setResults(List<Recipe> results) {
        this.results = results;
    }
}
